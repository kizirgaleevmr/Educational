// Объект для создания нового элемента
export class CreateItemDto {
  id?: string;
  name: string;
  description: string;
}
