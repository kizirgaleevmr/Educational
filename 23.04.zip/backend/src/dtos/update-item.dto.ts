// Объект для частичного обновления существующего элемента
export class UpdateItemDto {
  readonly name?: string;
  readonly description?: string;
}
