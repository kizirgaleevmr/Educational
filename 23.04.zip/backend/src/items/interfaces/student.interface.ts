export interface Student {
  id: string;
  name?: string;
  surname?: string;
  groupName?: string;
  address?: string;
  age?: number;
}