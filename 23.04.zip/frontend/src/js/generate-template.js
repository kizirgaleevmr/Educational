import { TABLE_BODY, STATE } from "./constants/global.js";
import { attachEditAndDeleteHandlers } from "./handlers.js";
/**
 * Функция отрисовки данных в таблице и их очистка
 */
export function renderTable(data) {
    let template = "";

    if (data && Array.isArray(data)) {
        data.forEach((student) => {
            template += `
                <tr id=${student.id}>
                    <td>${student.firstName}</td>
                    <td>${student.surname}</td>
                    <td>${student.address}</td>
                    <td>${student.age}</td>
                    <td>
                        <button class='button-edit'>Edit</button>
                        <button class='button-delete'>Delete</button>
                    </td>
                </tr>`;
        });
    }

    TABLE_BODY.innerHTML = "";
    TABLE_BODY.insertAdjacentHTML("beforeend", template);

    // обнуляем значения перед добавлением обработчиков
    STATE.clickedStudent = null;
    STATE.tableRowCheckedId = null;

    attachEditAndDeleteHandlers(data);
}
