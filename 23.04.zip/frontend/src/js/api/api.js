import { FORM } from "../constants/global.js";
import { resetForm } from "../helpers/reset-form.js";
import { Notification } from "../components/notification.js";
import { renderTable } from "../generate-template.js";
import axios from "axios";

/**
 * Функция отрисовки данных с сервера
 */
export const loadJSON = async () => {
    try {
        const response = await axios.get(`http://localhost:3000/students`);
        renderTable(response.data);
    } catch (error) {
        console.error("Ошибка загрузки данных:", error);
    }
};

/**
 * Функция добавления студента
 */
export const addStudent = async () => {
    const student = {};

    Array.from(FORM?.elements).forEach((element) => {
        if (element.name) {
            student[element.name] = element.value;
        }
    });

    try {
        const response = await axios.post(
            `http://localhost:3000/students`,
            student,
        );

        new Notification({
            title: "Информация о добавлении:",
            subtitle: "Студент успешно добавлен",
        });
        resetForm();
        loadJSON();
    } catch (error) {
        console.log("Error", error);
    }
};

/**
 * Функция обновляет измененные данные студента на сервере
 * @param {string} studentId - id студента
 * @param {object} updateStudentData - Обновленные данные студента
 */
export const updateStudentData = async (studentId, updateStudentData) => {
    try {
        const response = await axios.put(
            `http://localhost:3000/students/${studentId}`,
            updateStudentData,
        );

        new Notification({
            title: "Информация о обновлении:",
            subtitle: "Студент успешно обновлен",
        });
        loadJSON();
    } catch (error) {
        console.log("Error updating student data:", error);
    }
};

/**
 * Функция удаления студента из таблицы и из сервера
 * @param {string} studentId - id студента
 */
export const deleteStudent = async (studentId) => {
    try {
        const response = await axios.delete(
            `http://localhost:3000/students/${studentId}`,
        );

        new Notification({
            title: "Информация о удалении:",
            subtitle: "Студент успешно удален",
        });
        resetForm();
        loadJSON();
    } catch (error) {
        console.log("Error", error);
    }
};
