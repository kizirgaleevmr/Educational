import { FORM, SUBMIT_BUTTON } from "../constants/global.js";

// Функция отчистки формы
export const resetForm = () => {
    FORM.reset();

    SUBMIT_BUTTON.disabled = true;

    FORM.addEventListener("input", () => {
        const isFormValid = FORM.checkValidity();
        isFormValid && (SUBMIT_BUTTON.disabled = false);
    });
};
