import {
    FORM,
    STATE,
    FIRST_NAME_INPUT,
    SURNAME_INPUT,
    ADDRESS_INPUT,
    AGE_INPUT,
    ADD_STUDENT_BUTTON,
} from "./constants/global.js";
import { resetForm } from "./helpers/reset-form.js";
import { addStudent, updateStudentData, deleteStudent } from "./api/api.js";
import { SIDEBAR } from "./constants/global.js";


// Обработчик клика по кнопке добавления студента
export const addStudentHandler = () => {
    ADD_STUDENT_BUTTON.addEventListener("click", () => {
        SIDEBAR.open();
    });
};

/**
 *
 * Обработчик редактирования студента
 * @param {object} event - Объект события
 * @param {array} data - Массив данных
 */
export const editStudent = (event, data) => {
    STATE.tableRowCheckedId = event.target.closest("tr")?.id;

    const clickedStudentData = data.find(
        (student) => student.id === STATE.tableRowCheckedId,
    );

    if (clickedStudentData) {
        STATE.clickedStudent = clickedStudentData;
        FIRST_NAME_INPUT.value = clickedStudentData.firstName;
        SURNAME_INPUT.value = clickedStudentData.surname;
        ADDRESS_INPUT.value = clickedStudentData.address;
        AGE_INPUT.value = clickedStudentData.age;

        // Открываем сайдбар
        SIDEBAR.open();
    }
};

/**
 *
 * Обработчик событий для кнопок редактирования и удаления студентов
 * @param {array} data - Массив данных (Need to fix)
 */
export const attachEditAndDeleteHandlers = (data) => {
    // Получение кнопок для редактирования студента
    const editButtons = document?.querySelectorAll(".button-edit");
    // Получение кнопок для удаления студента
    const deleteButtons = document?.querySelectorAll(".button-delete");

    editButtons.forEach((editButton) => {
        editButton.removeEventListener("click", (event) => {
            editStudent(event, data);
        });
        editButton.addEventListener("click", (event) => {
            editStudent(event, data);
        });
    });

    deleteButtons.forEach((deleteButton) => {
        deleteButton.removeEventListener("click", () => {
            deleteStudent(data);
        });

        deleteButton.addEventListener("click", (event) => {
            const parent = event.target.closest("tr"); // Достаем родительский элемент
            const rowId = parent?.id; // id для удаления

            const confirm = window.confirm(
                "Вы уверены, что хотите удалить данные студента?",
            );

            if (rowId && confirm) {
                deleteStudent(rowId);
                parent.remove();
            }
        });
    });
};

/**
 * Обработчик события отправки формы
 */
FORM.addEventListener("submit", (e) => {
    e.preventDefault();
    if (STATE.tableRowCheckedId) {
        STATE.clickedStudent.firstName = FIRST_NAME_INPUT.value;
        STATE.clickedStudent.surname = SURNAME_INPUT.value;
        STATE.clickedStudent.address = ADDRESS_INPUT.value;
        STATE.clickedStudent.age = AGE_INPUT.value;
        updateStudentData(STATE.tableRowCheckedId, STATE.clickedStudent);
        resetForm();
        SIDEBAR.close();
    } else {
        addStudent();
        SIDEBAR.close();
    }
});
