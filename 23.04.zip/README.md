# Fullstack project

## Install

### Backend

- Install Node.js
  - Recomended version - 14.8 LTS
  - From [website](https://nodejs.org/en/)
  - From [nvm](https://github.com/nvm-sh/nvm) (recomended)
- Install dependencies
  ```bash
  cd backend
  npm install
  ```
- Run backend and frontend
  ```bash
  npm run server
  ```

### Frontend

- Install Node.js
  - Recomended version - 14.8 LTS
  - From [website](https://nodejs.org/en/)
  - From [nvm](https://github.com/nvm-sh/nvm) (recomended)
- Install dependencies
  ```bash
  cd frontend
  npm install
  ```